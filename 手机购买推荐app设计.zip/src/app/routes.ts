import { createBrowserRouter } from 'react-router';
import { Layout } from './components/Layout';
import { HomePage } from './components/HomePage';
import { AboutPage } from './components/AboutPage';
import { HandMeasurement } from './components/HandMeasurement';
import { PhoneSelection } from './components/PhoneSelection';
import { ModelPresets } from './components/ModelPresets';
import { ParamPreview } from './components/ParamPreview';
import { GripReport } from './components/GripReport';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: HomePage },
      { path: 'about', Component: AboutPage },
      { path: 'hand-measure', Component: HandMeasurement },
      { path: 'phone-select', Component: PhoneSelection },
      { path: 'model-presets', Component: ModelPresets },
      { path: 'grip-preview', Component: ParamPreview },
      { path: 'grip-report', Component: GripReport },
      { path: 'param-preview', Component: ParamPreview },
      { path: 'custom-params', Component: ParamPreview },
      { path: 'preview', Component: GripReport },
      { path: '*', Component: HomePage },
    ],
  },
]);